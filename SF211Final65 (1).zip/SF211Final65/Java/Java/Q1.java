public class Q1 {
    public static void main(String[] args) {
        WeatherForecast w1 = new WeatherForecast();
        System.out.println(w1);
        System.out.println(w1
        .setTemperature(100)
        .getTemperature());
        System.out.println(w1
        .setCondition(WeatherCondition.RAINY)
        .getCondition());
        WeatherForecast w2 = new WeatherForecast(100, WeatherCondition.RAINY);
        System.out.println(w1.equals(w2));
        w2.setTemperature(32);
        System.out.println(w1.equals(w2));
        System.out.println(w2.toCelcius());
        System.out.println(w2 + "\n" + w2.isConsistent());
        w2.setTemperature(0);
        System.out.println(w2 + "\n" + w2.isConsistent());
        w2.setCondition(WeatherCondition.CLOUDY);
    }
}