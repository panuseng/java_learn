import java.util.Random;
public class Q2 {
    public static void main(String[] args) {
        Random rnd = new Random();
        Coins c = new Coins(rnd.nextInt(50), rnd.nextInt(50), 
            rnd.nextInt(50), rnd.nextInt(50));
        System.out.println(c);
        System.out.println(c.total());
        System.out.println(c.quartersValue());
        System.out.println(c.dimesValue());
        System.out.println(c.nicklesValue());
        System.out.println(c.penniesValue());
        Coins c2 = new Coins();
        System.out.println(c2.equals(c));
        c = new Coins();
        System.out.println(c2.equals(c));
    }
}
