// Name (in English):
// ID:

public class Q1 {
public static void main(String[] args) {
	BMI myBMI = new BMI(70.2, 1.65);
	BMI yourBMI = new BMI(80.5, 1.91);
	System.out.println("My BMI:\n" + myBMI);
	System.out.println("Your BMI:\n" + yourBMI);
	System.out.println("Your BMI and my BMI are " + (myBMI.equals(yourBMI) ? "the same." : "not the same."));
	System.out.println("Your BMI is " + (yourBMI.getBMI() > myBMI.getBMI() ? "larger" : "smaller") + " than mine.");

	myBMI.setWeight(60.8).setHeight(1.66);
	System.out.println("My BMI:\n" + myBMI);
	System.out.println("Your BMI and my BMI are now " + (myBMI.equals(yourBMI) ? "the same." : "not the same."));
}
}

// WRITE YOUR CODE HERE
class BMI{

	private double Weight;
	private double Height;

	public BMI (double Weight, double Height){
		setWeight(Weight);
		setHeight(Height);
	}

	public BMI setWeight (double Weight){
		if (Weight > 0){
			this.Weight = Weight;
		}
		return this;
	}

	public BMI setHeight (double Height){
		if (Height > 0){
			this.Height = Height;
		}
		return this;
	}

	public double getBMI(){
		return Weight/(Height * Height);
	}

	public String getLevel(){
		if (getBMI() < 18.5) return "underweight";
		else if (getBMI() < 25) return "normal";
		else if (getBMI() < 30) return "overweight";
		else return "obesity";
	}

	public String toString(){
		return "\tWeight: " + Weight + "\n\tHeight: " + Height + "\n\tBMI: " + getBMI() + "\n\tLevel: " + getLevel();
	}

	final double TOLERANCE = 0.01;
	public boolean equals(Object other){
		if (!(other instanceof BMI)) return false;
		BMI o = (BMI) other;
		return Math.abs(getBMI() - o.getBMI()) < TOLERANCE;
	}
}
