public class WeatherForecast {
    private int temperature;
    private WeatherCondition condition;
    public WeatherForecast() {
        temperature = 70;
        condition = WeatherCondition.SUNNY;
    }
    public WeatherForecast(int temperature, WeatherCondition condition) {
        setTemperature(temperature);
        this.condition = condition;
    }
    public int getTemperature() { return temperature; }
    public WeatherCondition getCondition() { return condition; }
    public WeatherForecast setTemperature(int temperature) {
        if (temperature >= -50 && temperature <= 150)
            this.temperature = temperature;
        return this;
    }
    public WeatherForecast setCondition(WeatherCondition condition) {
        this.condition = condition;
        return this;
    }
    public String toString() {
        return "The temperature is " + temperature + "°F (" + condition + ")"; 
    }
    public boolean equals(Object other) {
        if (!(other instanceof WeatherForecast)) return false;
        WeatherForecast obj = (WeatherForecast) other;
        return temperature == obj.temperature && condition.equals(obj.condition);
    }
    public int toCelcius() {
        return (temperature - 32) * 5 / 9;
    }
    public boolean isConsistent() {
        return !(temperature > 32 && condition.equals(WeatherCondition.SNOWY)) && 
            !(temperature < 32 && condition.equals(WeatherCondition.RAINY));
    }
}

enum WeatherCondition {
    SUNNY, SNOWY, CLOUDY, RAINY;
    public String toString() {
        switch (this) {
            case SUNNY: return "Sunny";
            case SNOWY: return "Snowy";
            case CLOUDY: return "Cloudy";
            default: return "Rainy";
        }
    }
}