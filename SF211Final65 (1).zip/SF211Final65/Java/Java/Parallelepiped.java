public class Parallelepiped extends Rectangle {
    private double length;
    public Parallelepiped(double width, double height, double length) {
        super(width, height);
        this.length = length;
    }
    public double area() {
        return super.area() * 2 + perimeter() * length;
    }
    public double volume() {
        return super.area() * length;
    }
}
