import java.util.Random;
public class Q4 {
    public static void main(String[] args) {
        Garage g = new Garage();
        Random rnd = new Random();
        for (int i = 0; i < 100; i++) {
            g.addAuto(new Auto(rnd.nextInt(100), rnd.nextInt(10)));
        }
        System.out.println(g.status());
        System.out.println(g.averageMiles());
        System.out.println(g.totalGallons());
    }
}
