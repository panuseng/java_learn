import java.text.DecimalFormat;
public class Coins {
    private static final DecimalFormat CURRENCY_FORMATTER = new DecimalFormat("$#,##0.00");
    private int quarters;
    private int dimes;
    private int nickles;
    private int pennies;
    public Coins() {};
    public Coins(int q, int d, int n, int p) {
        quarters = q; dimes = d; nickles = n; pennies = p;
    }
    public String toString() {
        return "You have " + quarters + " quarters, " +
        dimes + " dimes, " + nickles + " nickles, " + 
        pennies + " pennies.";
    }
    public boolean equals(Object other) {
        if (!(other instanceof Coins)) return false;
        Coins o = (Coins) other;
        return quarters == o.quarters && dimes == o.dimes &&
        nickles == o.nickles && pennies == o.pennies;
    }
    public String total() {
        double total = quarters * 0.25 + dimes * 0.1 + 
            nickles * 0.05 + pennies * 0.01;
        return CURRENCY_FORMATTER.format(total);
    }
    public String quartersValue() {
        return CURRENCY_FORMATTER.format(quarters * 0.25);
    }
    public String dimesValue() {
        return CURRENCY_FORMATTER.format(dimes * 0.1);
    }
    public String nicklesValue() {
        return CURRENCY_FORMATTER.format(nickles * 0.05);
    }
    public String penniesValue() {
        return CURRENCY_FORMATTER.format(pennies * 0.01);
    }
}
