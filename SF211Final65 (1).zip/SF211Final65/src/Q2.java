// Name (in English): 
// ID: 

public class Q2 {
  public static void main(String[] args) {
    Phonebook phonebook = new Phonebook();
    System.out.println(phonebook);
    phonebook.addPhone("Jaguar", "0885551234");
    phonebook.addPhone("Bella", "0885551234");
    phonebook.addPhone("Bella", "0885559999");
    phonebook.addPhone("Jesse", "0115551234");
    phonebook.addPhone("Jaguar", "0122334455");
    System.out.println(phonebook);
    System.out.println("0885551234 belongs to " + phonebook.getName("0885551234"));
    System.out.println("Jaguar's phone numbers:");
    for (String number : phonebook.getNumbers("Jaguar"))
      System.out.println(number);
    if (phonebook.removePhone("0115551234"))
      System.out.println(phonebook);
    if (phonebook.removePhone("0115551234"))
      System.out.println(phonebook);
  }
}

class Phone {
  private String name;
  private String number;

  public Phone(String name, String number) {
    setName(name);
    setNumber(number);
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getName() {
    return name;
  }

  public String getNumber() {
    return number;
  }

  public String toString() {
    return name + " - " + number;
  }
}

// WRITE YOUR CODE HERE