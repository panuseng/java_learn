public class Q5 {
    public static void main(String[] args) {
        Rectangle rect = new Rectangle(20, 15);
        System.out.println("Perimeter = " + rect.perimeter());
        System.out.println("Area = " + rect.area());

        Parallelepiped prism = new Parallelepiped(20, 15, 5);
        System.out.println("Perimeter = " + prism.perimeter());
        System.out.println("Area = " + prism.area());
        System.out.println("Volume = " + prism.volume());
    }
    
}
