public class Auto {
    private int milesDriven;
    private int gallonOfGas;
    public Auto(int milesDriven, int gallonOfGas) {
        this.milesDriven = milesDriven;
        this.gallonOfGas = gallonOfGas;
    }
    public int getMilesDriven() { return milesDriven; }
    public int getGallonOfGas() { return gallonOfGas; }
}
