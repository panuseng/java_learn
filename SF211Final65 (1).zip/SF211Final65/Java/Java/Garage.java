import java.util.ArrayList;

public class Garage {
    private ArrayList<Auto> cars = new ArrayList<Auto>();

    public void addAuto(Auto auto) {
        cars.add(auto);
    }

    public double averageMiles() {
        double total = 0;
        for (Auto car: cars) {
            total += car.getMilesDriven();
        }
        return total / cars.size();
    }

    public String status() {
        if (cars.size() >= 100) return "Full";
        else if (cars.size() < 25) return "Below minimum";
        else return "Normal load";
    }

    public int totalGallons() {
        int total = 0;
        for (Auto car: cars) {
            total += car.getGallonOfGas();
        }
        return total;
    }
}
